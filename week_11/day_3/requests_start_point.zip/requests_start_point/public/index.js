var app = function () {

}

window.addEventListener('load', app);
