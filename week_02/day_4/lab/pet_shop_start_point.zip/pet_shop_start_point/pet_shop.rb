require_relative('pet')

class PetShop

  def initialize (input_pets)
    @pets = input_pets
  end

end