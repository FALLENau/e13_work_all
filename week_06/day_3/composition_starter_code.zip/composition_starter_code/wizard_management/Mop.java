package wizard_management;

public class Mop extends CleaningImplement {
  
  public Mop(String brand){
    super(brand);
  }

}