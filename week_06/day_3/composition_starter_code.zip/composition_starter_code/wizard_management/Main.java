package wizard_management;

public class Main {

  public static void main(String[] args){

  }
  
}