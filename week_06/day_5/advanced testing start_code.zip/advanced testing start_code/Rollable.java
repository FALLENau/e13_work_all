public interface Rollable {
  int roll();
}