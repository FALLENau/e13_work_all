class Vehicle {
  private int numWheels = 4;

  public Vehicle(){
    
  }

  public int getNumWheels(){
    return this.numWheels;
  }
}