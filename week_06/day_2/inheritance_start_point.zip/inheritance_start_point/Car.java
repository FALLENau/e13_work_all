class Car extends Vehicle {
  
}