public class Runner {
  public static void main(String[] args) {
    Bear bear = new PolarBear();
    bear.roar();
  }
}