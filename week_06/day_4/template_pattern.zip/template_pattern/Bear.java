public abstract class Bear {

  public abstract void gatherFood();

  public void roar(){
    System.out.println("roar!");
  }
  
}