public class Runner{
  public static void main(String[] args){
    ExampleTryCatch myProgram = new ExampleTryCatch();
    myProgram.run(); 
  }
    
}