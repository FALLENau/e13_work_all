public interface Pet{
  public String getName();
}