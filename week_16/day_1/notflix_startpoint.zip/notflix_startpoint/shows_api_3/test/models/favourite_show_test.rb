require 'test_helper'

class FavouriteShowTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
