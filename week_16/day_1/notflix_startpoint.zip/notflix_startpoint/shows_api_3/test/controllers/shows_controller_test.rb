require 'test_helper'

class ShowsControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
