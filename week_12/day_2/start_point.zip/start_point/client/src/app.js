var QuoteView = require('./views/quoteView');

var app = function(){
  
}


window.addEventListener('load', app);