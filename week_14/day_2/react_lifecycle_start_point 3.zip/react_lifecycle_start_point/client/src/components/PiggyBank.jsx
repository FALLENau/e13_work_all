import React from 'react';
import PropTypes from 'prop-types';
import Total from './Total.jsx';

class PiggyBank extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      total: 0,
      showTotal: true
    };
  }

  componentWillMount() {
  }

  componentDidMount() {
  }

  shouldComponentUpdate(nextProps, nextState){
    return true;
  }

  componentWillUpdate(nextProps, nextState){
  }

  componentDidUpdate(prevProps, prevState){
  }

  addToSavings() {
    this.setState((prevState) => {
      return {total: prevState.total + 1};
    });
  }

  hideTotal() {
    this.setState((prevState) => {
      return {showTotal: false};
    });
  }

  showTotal() {
    this.setState((prevState) => {
      return {showTotal: true};
    })
  }

  render() {
    let total = <div></div>;

    if(this.state.showTotal) {
      total = <Total total={this.state.total}></Total>;
    }

    return (
      <div className="bank-box">
        <h1>{this.props.title}</h1>
        <p>Hello, world! I am a Piggy Bank.</p>
        {total}
        <button onClick={ () => {this.addToSavings() } }>Add Funds</button>
        <button onClick={ () => {this.hideTotal() } }> Hide Total </button>
        <button onClick={ () => {this.showTotal() } }> Show Total </button>
      </div>
    );
  }
}

PiggyBank.propTypes = {
  title: PropTypes.string.isRequired
};

export default PiggyBank;