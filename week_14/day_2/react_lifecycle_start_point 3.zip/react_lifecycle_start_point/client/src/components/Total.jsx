import React from 'react';
import PropTypes from 'prop-types';

class Total extends React.Component {

  constructor(props) {
    super(props);
  }

  componentWillReceiveProps(nextProps){
  }

  shouldComponentUpdate(nextProps, nextState){
    return true;
  }

  componentWillUpdate(nextProps, nextState){
  }

  componentDidUpdate(prevProps, prevState){
  }

  componentWillMount() {
  }

  componentDidMount() {
  }

  componentWillUnmount() {
  }

  render() {
    return (
      <p>{this.props.total}</p>
    );
  }
}

export default Total;