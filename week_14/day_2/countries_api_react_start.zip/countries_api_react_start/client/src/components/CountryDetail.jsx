import React from 'react';

class CountryDetail extends React.Component {
  render(){
    return (
      <h3>
        Country details to go here.
      </h3>
    );
  }
}

module.exports = CountryDetail;
