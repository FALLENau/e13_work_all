import React from 'react';
import ReactDOM from 'react-dom';

window.onload = function(){
  ReactDOM.render(
    <h1> App Started </h1>,
    document.getElementById('app')
  );
}
