import React from 'react'

const About = () => (
  <div>
    <h4>About</h4>
    <p>Some information about us.</p>
  </div>
)

export default About
